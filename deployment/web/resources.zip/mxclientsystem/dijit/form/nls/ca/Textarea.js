//>>built
define("dijit/form/nls/ca/Textarea",({iframeEditTitle:"àrea d'edició",iframeFocusTitle:"Marc de l'àrea d'edició"}));

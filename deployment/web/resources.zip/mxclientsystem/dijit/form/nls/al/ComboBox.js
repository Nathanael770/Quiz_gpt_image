//>>built
define("dijit/form/nls/al/ComboBox",{previousMessage:"Zgjedhja e mëparshme",nextMessage:"Më tepër zgjedhje"});
